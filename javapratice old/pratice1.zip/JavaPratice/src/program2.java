/////conversion for integer into digits list
import java.util.Scanner;
import java.util.Set;
import java.util.HashSet;


public class program2 {
	long number,revNumber;
	Set<Integer> list;
	public program2(long number){
		this.number=number;
		list=new HashSet<>();
	}
	
	public void intToDigit() {
		long number=this.number;
		while(number>0) {
			int d=(int) (number%10);
			list.add(d);
			number/=10;
		}
	}
	
	public void revNumber() {
		long number=this.number;
		long rev=0;
		while(number>0) {
			long d=number%10;
			rev=rev*10+d;
			number/=10;
		}
		revNumber=rev;
	}
	
	public void displayDigits() {
		int count=0;
		for(int i:list) {
			count++;
			System.out.print(i+" ");
			if(count==10) {
				System.out.println();
				count=0;
			}
		}
		System.out.println();
	}
	
	public void displayReverseNumber() {
		System.out.println(revNumber);
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		program2 ob=new program2(sc.nextLong());
		sc.close();
		ob.intToDigit();
		ob.displayDigits();
		ob.revNumber();
		ob.displayReverseNumber();
	}

}
