import java.lang.Math;
import java.util.Scanner;
import java.util.LinkedList;

/////////// program to print first n prime numbers

///////// time complexity is O(n* sqrt(n))
/////// best algorithm is O(n*loglog n) - Sieve of Eratosthenes

public class program1 {

	private int numberOfTerms;
	
	public program1(int n) {
		numberOfTerms=n;
	}
	
	public int getNumberOfTerms() {
		return numberOfTerms;
	}
	
	public int isPrime(int num) {
		for(int i=2;i<=Math.sqrt(num);i++) {
			if(num%i==0) {
				return -1;
			}
		}
		return 0;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		LinkedList<Integer> l=new LinkedList<>();
		System.out.println("Enter the number to find all the prime numbers [2,n]");
		int numberOfTerms=sc.nextInt();
		sc.close();
		program1 ob=new program1(numberOfTerms);
		
		for(int i=2;i<=ob.getNumberOfTerms();i++) {
			
			if(ob.isPrime(i)==0) {
				l.add(i);
			}
		}
		int count=0;
		for(int i :l) {
			count++;
			System.out.printf("%02d ",i);
			if(count==10) {System.out.println();count=0;}
		}
		
		
		
	}
}