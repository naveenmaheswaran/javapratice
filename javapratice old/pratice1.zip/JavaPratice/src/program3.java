import java.util.Scanner;
public class program3 {
	double number,squreRoot,cubeRoot;
	program3(double number){
		this.number=number;
	}
	
	public void sqrt() {
		double start,end,mid;
		start=0;
		end=number;
		for(mid=(start+end)/2;start<=end;mid=(start+end)/2) {
			if(mid * mid==number) {
				this.squreRoot=mid;
			}else if(mid*mid>number) {
				end=mid-1;
			}else if(mid * mid<number) {
				start=mid+1;
			}
			
		}
		if(end*end==number) {
			this.squreRoot=end;
		}
		
		
	}
	
	public void printSqrt() {
		System.out.println(squreRoot);
	}
	
	public static void main(String[] arsg) {
		Scanner sc = new Scanner(System.in);
		program3 ob=new program3(sc.nextDouble());
		ob.sqrt();
		ob.printSqrt();
		sc.close();
	}
	
	

}
